from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import User
import bcrypt

def index(request):
    if 'authenticator' not in request.session:
        return render(request, 'registration/index.html')
    else:
        return render(request, 'registration/success.html')

def success(request):
    if 'authenticator' not in request.session:
        return render(request, 'registration/hacker.html')
    else:
        return render(request, 'registration/success.html')

def hacker(request):
    return render(request, 'registration/hacker.html')

def register(request):
    if request.method == 'POST':
        errors = User.objects.registration_validator(request.POST)
        if len(errors):
            for key, value in errors.items():
                messages.error(request, value, extra_tags='register')
            return redirect('/')
        else:
            create = User.objects.create_user(request.POST)
            messages.success(request, "User successfully created!")
            request.session['authenticator'] = User.objects.last().email_hash
            request.session['first_name'] = request.POST['first_name']
        return redirect('/success')    
    else:
        return redirect('/')

def login(request):
    if request.method == 'POST':
        errors = User.objects.login_validator(request.POST)
        if len(errors):
            for key, value in errors.items():
                messages.error(request, value, extra_tags='login')
            return redirect('/')
        else:
            messages.success(request, "User logged in successfully!")
            user = User.objects.get(email = request.POST['email'])
            request.session['authenticator'] = user.email_hash
            request.session['first_name'] = user.first_name
        return redirect('/success')    
    else:
        return redirect('/')

def logout(request):
    if request.method == 'POST':
        del request.session['first_name']
        del request.session['authenticator']
        return redirect('/')
    else:
        return redirect('/')