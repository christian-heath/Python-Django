from django.apps import AppConfig


class OfficialexamConfig(AppConfig):
    name = 'officialexam'
